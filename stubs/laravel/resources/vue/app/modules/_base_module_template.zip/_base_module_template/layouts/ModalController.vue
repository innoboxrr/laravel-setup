<template>

    <component
        :key="currentModal" 
        :is="currentComponent"
        :data="modalData"
        :open="modalOpened" 
        @close="closeModal" />

</template>

<script>

    import { shallowRef } from 'vue';
    import { mapState } from 'vuex';

    // This modal needs to be registered in the TestkinModule vuex module
    const components = {
        'create-testkin': () => import('./../modals/CreateTestkinModal.vue'),

        'edit-testkin': () => import('./../modals/EditTestkinModal.vue'),

        'show-testkin': () => import('./../modals/ShowTestkinModal.vue'),
    };

    export default {

        data() {
            return {
                currentComponent: shallowRef(null),
            }
        },

        computed: {
            ...mapState('testkinModule', [
                'currentModal',
                'modalData'
            ]),

            modalOpened() {
                return this.currentModal != null;
            },
        },

        watch: {
            currentModal: {
                immediate: true,
                handler(newValue, oldValue) {
                    this.loadComponent(newValue);
                }
            }
        },

        methods: {
            loadComponent(componentName) {
                if(componentName == null) return;
                const componentOrUndefined = components[componentName];
                if (componentOrUndefined) {
                    componentOrUndefined().then((resolvedComponent) => {
                        this.currentComponent = resolvedComponent.default;
                    }).catch(error => {
                        console.error(`Error loading component ${componentName}:`, error);
                    });
                } else {
                    console.error(`Component ${componentName} not found`);
                }
            },
            closeModal() {
                this.$store.dispatch('testkinModule/closeModal');
            },
        },
    }
</script>