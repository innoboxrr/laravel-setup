<template>
    <div class="flex min-w-0 flex-1 flex-col overflow-hidden main-container">
        <main class="flex flex-1 overflow-hidden">
            <div class="flex flex-1 flex-col overflow-y-auto xl:overflow-hidden">
                <nav aria-label="Breadcrumb" class="border-b border-slate-200 bg-white xl:hidden dark:bg-slate-700 dark:border-slate-600">
                    <div class="mx-auto flex max-w-3xl items-start px-4 py-3 sm:px-6 lg:px-8">
                        <a class="-ml-1 inline-flex items-center space-x-3 text-sm font-medium text-slate-900"
                            @click="isLeftSidebarOpen = !isLeftSidebarOpen">
                            <i v-if="isLeftSidebarOpen" class="fa-solid fa-angle-left text-slate-400"></i>
                            <i v-else class="fa-solid fa-angle-right text-slate-400 dark:text-slate-100"></i>
                            <span class="dark:text-gray-200">{{ __('Open sidebar nav') }}</span>
                        </a>
                    </div>
                </nav>
                <div class="flex flex-1 xl:overflow-hidden">
                    <div 
                        class="sidebar hide-scrollbar">
                        <left-sidebar 
                            class="w-full xl:w-96"
                            :class="{
                                hidden: !isLeftSidebarOpen,
                            }"
                            @stepUpdated="handleStepUpdate"/>
                    </div>
                    <div 
                        class="main-content flex-1 xl:overflow-y-auto hide-scrollbar"
                        :class="{
                            hidden: isLeftSidebarOpen,
                        }">
                        <div>
                            <slot></slot>
                        </div>
                    </div>
                </div>
            </div>
            <modal-controller />
        </main>
    </div>
</template>

<script>

    import LeftSidebar from './LeftSidebar.vue'
    import ModalController from './ModalController.vue'
    import { debounce } from 'innoboxrr-js-libs/libs/utils.js'

    export default {
        components: {
            LeftSidebar,
            ModalController
        },
        data() {
            return {
                isLeftSidebarOpen: false,
                debouncedResize: null
            }
        },
        mounted() {
            this.preventOverflow();
            // Close the left sidebar on window resize
            // This is necessary to close the sidebar when the window is resized
            this.$nextTick(() => {
                this.debouncedResize = debounce(() => {
                    this.isLeftSidebarOpen = false;
                    this.preventOverflow();
                }, 100);
                window.addEventListener('resize', this.debouncedResize);
            });
        },
        beforeUnmount() {
            // Remove the resize event listener
            window.removeEventListener('resize', this.debouncedResize);
            document.documentElement.style.overflow = 'auto';
        },
        methods: {
            // Also close the left sidebar when a step is updated
            // This is necessary when the user clicks on a step in the left sidebar
            handleStepUpdate(step) {
                this.isLeftSidebarOpen = false;
                this.$emit('stepUpdated', step);
            },
            preventOverflow() {
                // Mover el scroll al inicio 
                window.scrollTo(0, 0);
                // Add overflow hidden al html solo cuando min-width: 1280px
                // Esto es necesario para evitar que el contenido se desborde en pantallas grandes
                // y se muestre la barra de desplazamiento
                if(window.innerWidth >= 1280) {
                    document.documentElement.style.overflow = 'hidden';
                } else {
                    document.documentElement.style.overflow = 'auto';
                }
            }
        }
    }

</script>

<style scoped>
    @media (min-width: 1280px) {
        .sidebar {
            height: calc(100vh - 63px);   
            max-height: calc(100vh - 63px) !important;
            overflow-y: auto;
        }
        .main-content {
            height: calc(100vh - 63px);
            max-height: calc(100vh - 63px) !important;
            overflow-y: auto;
        }
    }
</style>
