<template>
    <modal-component
        ref="modalRef" 
        id="createTestkinModal"
        :open="open"
        @close="modalClosed"
        :title="__('Create Testkin')"
        :large-modal="false">
        <template v-slot:body>
            <div class="p-4">
                <testkin-create-form @submit="testkinCreateFormSubmit" />
            </div>
        </template>
    </modal-component>
</template>

<script>

    import TestkinCreateForm from '@models/testkin/forms/CreateForm.vue'

    export default {

        components: {
            TestkinCreateForm,
        },

        props: {
            open: {
                type: Boolean,
                default: false,
            },
            data: {
                type: Object,
                default: () => {
                    return {}
                }
            }
        },

        emits: ['close'],

        methods: {
            closeModal() {
                this.$refs.modalRef.closeModal();
            },
            modalClosed() {
                this.$emit('close');
            },
            async testkinCreateFormSubmit(testkin) {
                this.alert('success');
                // Pending. Implement function that only add the new testkin to the list, and not fetch all testkins again
                await this.$store.dispatch('testkinModule/fetchTestkins');
                this.closeModal();
            }
        }
    }
</script>