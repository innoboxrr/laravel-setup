import { indexModel as indexTestkinModel } from '@models/testkin';

export default {

	namespaced: true,

	state() {
		return {
			title: 'Testkin Module',
            currentStep: null,
			allowedSteps: [
				'home',
				'testkin-create',
				'testkin-report',
			],
			currentModal: null,
			modalData: {},

			// You need to register the modals in ModalController Component
			allowedModals: [
				'create-testkin',
				
				'edit-testkin',
				
				'show-testkin',
			],
			
			// testkin editor
			testkins: [],
			testkin: null,
			
		}
	},

	getters: {
		//
	},

	mutations: {
		setCurrentStep(state, step) {
            state.currentStep = step;
        },
		setTestkins(state, testkins) {
			state.testkins = testkins;
		}
	},

	actions: {
		
		async initModule({ dispatch, commit, state }, { data = {} }) {
			await dispatch('fetchTestkins');
			const step = data.step && state.allowedSteps.includes(data.step) ? data.step : 'home';
			commit('setCurrentStep', step);
		},

		async fetchTestkins({ commit }) {
			const testkins = await indexTestkinModel({
				paginate: 0,
			});
			commit('setTestkins', testkins);
		},

		openModal({ commit }, {modalName, data = {}}) {
			commit('setCurrentModal', modalName);
			commit('setModalData', data);
		},

		closeModal({ commit }) {
			commit('setCurrentModal', null);
			commit('setModalData', {});
		}
	}
}