<template>
    <nav aria-label="Sections" class="flex-shrink-0 border-r border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 xl:flex xl:flex-col">
        <div class="flex h-16 flex-shrink-0 items-center border-b border-slate-200 dark:border-slate-700 px-6">
            <p class="text-lg font-medium text-slate-900 dark:text-slate-200">
                {{ __('Manage Testkings') }}
            </p>
        </div>
        <div class="min-h-0 flex-1 overflow-y-auto">
            <a v-for="(item, index) in menuItems" 
                :key="index"
                :class="{
                    'bg-blue-50 bg-opacity-50 border-slate-200 dark:bg-slate-700': item.selected,
                    'hover:bg-blue-50 hover:bg-opacity-50 dark:hover:bg-slate-700': !item.selected,
                    'flex border-b p-6 dark:border-slate-600': true,
                }"
                aria-current="page"
                @click="setStep(item.id)">
                <i :class="[item.icon, 'text-slate-400 mt-1']"></i>
                <div class="ml-3 text-sm">
                    <p class="font-medium text-slate-900 dark:text-slate-200">{{ item.title }}</p>
                    <p class="mt-1 text-slate-500 dark:text-slate-400">{{ item.description }}</p>
                </div>
            </a>
        </div>
    </nav>
</template>

<script>

import { leftSidebarMenuItems as menuItems } from '../config';

export default {
    emits: ['stepUpdated'],
    data() {
        return {
            menuItems: menuItems,
        };
    },
    mounted() {
        // Set the current step based on the query parameter
        const step = this.$route.query.step;
        if(step) {
            this.setStep(step);
        }
    },
    computed: {
        currentStep() {
            return this.$store.state.testkinModule.currentStep;
        },
    },
    methods: {
        setStep(stepId) {

            // Update the selected step
            this.menuItems.forEach(item => {
                item.selected = (item.id === stepId);
            });

            // Update the current step in the store
            this.$store.commit('testkinModule/setCurrentStep', stepId);

            // Update query url with the current step
            this.$router.push({ query: { ...this.$route.query, step: stepId } });

            // Emit the event to the parent component. Probably this is not necessary
            this.$emit('stepUpdated', stepId);
        },
    },
}
</script>
