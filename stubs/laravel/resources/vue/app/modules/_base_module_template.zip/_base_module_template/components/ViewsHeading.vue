<template>
    <div>
        <div class="sm:col-span-6 mb-6">
            <h1 class="text-3xl font-bold tracking-tight text-slate-900 dark:text-slate-200 mb-8">
                {{ title }}
            </h1>
            <h2 class="text-xl font-medium text-slate-900 dark:text-slate-200">
                {{ subtitle }}
            </h2>
            <p class="mt-1 text-sm text-slate-500 dark:text-slate-400">
                {{ description }}
            </p>
        </div>
    </div>
</template>
<script>
export default {
    props: {
        title: {
            type: String,
            required: true
        },
        subtitle: {
            type: String,
            required: false,
            default: null
        },
        description: {
            type: String,
            required: false,
            default: null
        }
    }
}
</script>