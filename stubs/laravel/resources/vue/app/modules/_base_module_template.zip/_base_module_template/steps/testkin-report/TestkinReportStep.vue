<template>
    <div class="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8 lg:py-12">
        <views-heading
            :title="__('Testkings Report')"
            :subtitle="__('Here you can see the behavior of your testkings')"
            :description="__('Follow up the behavior of your testkings.')" />
        
        <p>Testkin create.</p>
    </div>
</template>
<script>
import ViewsHeading from "./../../components/ViewsHeading.vue";

export default {
    components: {
        ViewsHeading,
    },
};
</script>
