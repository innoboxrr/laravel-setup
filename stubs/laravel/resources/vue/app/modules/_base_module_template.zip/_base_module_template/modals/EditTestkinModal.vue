<template>
    <modal-component 
        ref="modalRef" 
        id="editTestkinModal"
        :open="open"
        @close="$emit('close')"
        :large-modal="false">
        <template v-slot:body>
            <div class="p-4">
                <testkin-edit-form 
                    :testkin-id="testkinId"
                    @submit="testkinEditFormSubmit" />
            </div>
        </template>
    </modal-component>
</template>

<script>

    import TestkinEditForm from '@models/testkin/forms/EditForm.vue'

    export default {

        components: {
            TestkinEditForm,
        },

        props: {
            open: {
                type: Boolean,
                default: false,
            },
            data: {
                type: Object,
                default: () => {
                    return {}
                }
            }
        },

        emits: ['close'],

        data() {
            return {
                testkinId: this.data?.testkin?.id,
            }
        },

        methods: {
            closeModal() {
                this.$refs.modalRef.closeModal();
            },
            modalClosed() {
                this.$emit('close');
            },
            async testkinEditFormSubmit(testkin) {
                this.alert('success');
                // Pending. Implement function that only add the new testkin to the list, and not fetch all testkins again
                await this.$store.dispatch('testkinModule/fetchTestkins');
                this.closeModal();
            }
        }
    }
</script>