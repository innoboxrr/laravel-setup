export const leftSidebarMenuItems = [
    {
        id: 'home',
        icon: 'fa-solid fa-home',
        title: 'Home',
        description: 'Welcome to Testkings!',
        selected: true
    },
    {
        id: 'testkin-create',
        icon: 'fa-solid fa-plus',
        title: 'Create Testkin',
        description: 'Create a new testkin',
        selected: false
    },
    {
        id: 'testkin-report',
        icon: 'fa-solid fa-chart-bar',
        title: 'Testkin Report',
        description: 'View testkin report',
        selected: false
    },
    // Agrega los demás elementos aquí...
];