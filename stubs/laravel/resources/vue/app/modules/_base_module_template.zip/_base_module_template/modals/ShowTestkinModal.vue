<template>
    <modal-component 
        class="h-screen"
        id="showTestkinModal"
        :open="open"
        @close="$emit('close')"
        :large-modal="true"
        :title="`${title}`">
        <template v-slot:body>
            <div v-if="dataLoaded">

                <div
                    v-if="testkinId" 
                    class="mx-auto max-w-6xl lg:flex lg:gap-x-8 lg:px-8">
                    <h1 class="sr-only">Testkin</h1>

                    <aside class="flex overflow-x-auto border-b border-gray-900/5 py-4 lg:block lg:w-64 lg:flex-none lg:border-0 lg:py-4">
                        <nav class="flex-none px-4 sm:px-6 lg:px-0">
                            <ul role="list" class="flex gap-x-3 gap-y-1 whitespace-nowrap lg:flex-col">
                                <li v-for="item in items" :key="item.id">
                                    <a 
                                        :href="item.url" 
                                        :class="[
                                            'group flex items-center gap-x-3 rounded-md py-2 pl-2 pr-3 text-sm leading-6 font-semibold dark:hover:text-gray-300',
                                            item.type === type ? 'bg-gray-800 text-indigo-300' : 'text-gray-400 hover:bg-gray-700 hover:text-indigo-300'
                                        ]"
                                        @click="type = item.type">
                                    <i 
                                        :class="[
                                            'fas', // clase base para FontAwesome
                                            item.icon, // clase de icono específico para cada item
                                            item.type === type ? 'text-indigo-300' : 'text-gray-400'
                                        ]"
                                        aria-hidden="true">
                                    </i>
                                    {{ item.name }}
                                    </a>
                                </li>
                            </ul>
                        </nav>
                    </aside>

                    <main class="px-4 py-16 sm:px-6 lg:flex-auto lg:px-20 lg:py-4">
                        <div class="mx-auto max-w-2xl space-y-16 sm:space-y-20 lg:mx-0 lg:max-w-none">
                            <div v-if="type == 'theory'">
                                <h2 class="text-base font-semibold leading-7 dark:text-gray-300 text-gray-900">
                                    {{ __('Details') }}
                                </h2>
                                <p class="mt-1 text-sm leading-6 dark:text-gray-400 text-gray-700 pb-6">
                                    {{ __('The theory of the testkin') }}
                                </p>

                                
                            </div>

                            <div v-if="type == 'video'">
                                <h2 class="text-base font-semibold leading-7 dark:text-gray-300 text-gray-900">
                                    {{ __('Demo PDF') }}
                                </h2>
                                <p class="mt-1 text-sm leading-6 dark:text-gray-400 text-gray-700 pb-6">
                                    {{ __('The demo testking PDF') }}
                                </p>

                                
                            </div>

                            <div v-if="type == 'video'">
                                <h2 class="text-base font-semibold leading-7 dark:text-gray-300 text-gray-900">
                                    {{ __('Full PDF') }}
                                </h2>
                                <p class="mt-1 text-sm leading-6 dark:text-gray-400 text-gray-700 pb-6">
                                    {{ __('The full testking PDF') }}
                                </p>

                                
                            </div>
                        </div>
                    </main>
                </div>
            </div>
        </template>
    </modal-component>
</template>

<script>

    import { showModel as showTestkinModel } from '@models/testkin'

    export default {

        components: {
            //
        },

        props: {
            open: {
                type: Boolean,
                default: false,
            },
            data: {
                type: Object,
                default: () => {
                    return {}
                }
            },
        },

        emits: ['close'],  
        
        data() {
            return {
                dataLoaded: false,
                testkin: null,
                title: '',
                testkinId: this.data?.testkin?.id,
                items: [
                    { 
                        id: 1, 
                        name: 'Details', 
                        type: 'details', 
                        url: '#details', 
                        icon: 'fa-info-circle'
                    },
                    { 
                        id: 2, 
                        name: 'Demo PDF', 
                        type: 'demo', 
                        url: '#demo', 
                        icon: 'fa-file-pdf'
                    },
                    { 
                        id: 3, 
                        name: 'Full PDF', 
                        type: 'full', 
                        url: '#full', 
                        icon: 'fa-file-pdf'
                    },
                    // { id: 3, name: 'Testkin preview', type: 'preview', url: '#preview', icon: 'fa-eye' },
                ],
                type: 'details',
            }
        },

        async mounted() {
            await this.fetchTestkin();
            this.dataLoaded = true;
            this.title = this.testkin?.name;
        },

        methods: {
            async fetchTestkin() {
                if(!this.testkinId) return;
                this.testkin = await showTestkinModel(this.testkinId);
            },
            closeModal() {
                this.$refs.modalRef.closeModal();
            },
            modalClosed() {
                this.$emit('close');
            },
        }
    }
</script>