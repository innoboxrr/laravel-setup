<template>
    <div class="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8 lg:py-12">
        <views-heading
            :title="__('Create new testking')"
            :subtitle="__('Fill out the form to set up your testkin details')"
            :description="__('Complete the form below to define your testkin. You have the flexibility to adjust these details at any time as needed.')" />
        
        <p>Testkin create.</p>
    </div>
</template>
<script>
import ViewsHeading from "./../../components/ViewsHeading.vue";

export default {
    components: {
        ViewsHeading,
    },
};
</script>
