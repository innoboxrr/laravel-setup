import TestkinLayout from "./TestkinLayout.vue";

export default TestkinLayout;