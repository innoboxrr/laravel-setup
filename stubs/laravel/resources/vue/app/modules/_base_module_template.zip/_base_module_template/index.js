import TestkinModule from "./TestkinModule.vue";

export default TestkinModule;