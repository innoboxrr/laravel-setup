<template>
    <testkin-layout>
        <component 
            :key="currentStep"
            :is="currentComponent" />
    </testkin-layout>
</template>

<script>

    import { shallowRef } from 'vue';
    import { mapState } from 'vuex';
    import TestkinLayout from './layouts'

    // Any component that is going to be loaded dynamically must be imported here
    const components = {
        'home': () => import('./steps/home/HomeStep.vue'),
        'testkin-create': () => import('./steps/testkin-create/TestkinCreateStep.vue'),
        'testkin-report': () => import('./steps/testkin-report/TestkinReportStep.vue'),
    };
    
    export default {
        name: 'TestkinModule',
        components: {
            TestkinLayout,
        },
        async created() {
            await this.initModule();
        },
        data() {
            return {
                currentComponent: shallowRef(null),
            };
        },
        computed: {
            ...mapState('testkinModule', [
                'currentStep',
            ]),
        },
        watch: {
            currentStep: {
                immediate: true,
                handler(newValue, oldValue) {
                    this.loadComponent(newValue);
                }
            }
        },
        methods: {
            async initModule() {
                await this.$store.dispatch('testkinModule/initModule',{
                    data: {
                        step: this.$route.query.step || null,
                    }
                });
            },
            loadComponent(componentName) {
                if(componentName == null) return;
                const componentOrUndefined = components[componentName];
                if (componentOrUndefined) {
                    componentOrUndefined().then((resolvedComponent) => {
                        this.currentComponent = resolvedComponent.default;
                    }).catch(error => {
                        console.error(`Error loading component ${componentName}:`, error);
                    });
                } else {
                    console.error(`Component ${componentName} not found`);
                }
            },
        },
    }
</script>